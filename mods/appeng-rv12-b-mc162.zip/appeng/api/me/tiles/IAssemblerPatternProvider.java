package appeng.api.me.tiles;

import appeng.api.me.util.IAssemblerPattern;

/**
 * Both useless and incredibly useful, maybe...
 */
public interface IAssemblerPatternProvider
{
    public IAssemblerPattern provideAssemblerPattern();
}
