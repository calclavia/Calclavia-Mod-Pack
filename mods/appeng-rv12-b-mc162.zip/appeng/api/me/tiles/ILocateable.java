package appeng.api.me.tiles;

public interface ILocateable
{
	/**
	 * returns the serial for a locateable object.
	 * @return
	 */
	long getLocatableSerial();
}
